// Dado el siguiente javascript usa forof y forin para hacer la media del
// volumen de todos los sonidos favoritos que tienen los usuarios.

const users = [
  {
    name: 'Alberto',
    favoritesSounds: {
      waves: { format: 'mp3', volume: 50 },
      rain: { format: 'ogg', volume: 60 },
      firecamp: { format: 'mp3', volume: 80 }
    }
  },
  {
    name: 'Antonio',
    favoritesSounds: {
      waves: { format: 'mp3', volume: 30 },
      shower: { format: 'ogg', volume: 55 },
      train: { format: 'mp3', volume: 60 }
    }
  },
  {
    name: 'Pedro',
    favoritesSounds: {
      shower: { format: 'mp3', volume: 50 },
      train: { format: 'ogg', volume: 60 },
      firecamp: { format: 'mp3', volume: 80 }
    }
  },
  {
    name: 'Cristina',
    favoritesSounds: {
      waves: { format: 'mp3', volume: 67 },
      wind: { format: 'ogg', volume: 35 },
      firecamp: { format: 'mp3', volume: 60 }
    }
  }
];

//? hay que guardar en variables el valor del volumen de cada sonido (que se tiene que ir sumando) y el total de sonidos, para cada usuario
//? hay que tener en cuenta que no todos los usuarios tienen los mismos sonidos, así que si no existe, el valor del volumen tendrá que ser 0, para evitar undefined.

let totalVolume = 0;
let soundsCounter = 0;

for (const user of users) {
  for (const sound in user.favoritesSounds) {
    const volume = user.favoritesSounds[sound].volume || 0;
    totalVolume += volume;
    soundsCounter++;
  }
}
const averageVolume = totalVolume / soundsCounter;
console.log(averageVolume);

//RESULTADO
// 57.25
