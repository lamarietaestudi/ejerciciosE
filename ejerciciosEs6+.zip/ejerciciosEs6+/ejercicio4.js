// 4.1 Dado el siguiente array, devuelve un array con sus nombres
// utilizando .map().
const users = [
  { id: 1, name: 'Abel' },
  { id: 2, name: 'Julia' },
  { id: 3, name: 'Pedro' },
  { id: 4, name: 'Amanda' }
];
const userNames = users.map((user) => user.name);
console.log(userNames);

// 4.2 Dado el siguiente array, devuelve una lista que contenga los valores
// de la propiedad .name y cambia el nombre a 'Anacleto' en caso de que
// empiece por 'A'.
const users2 = [
  { id: 1, name: 'Abel' },
  { id: 2, name: 'Julia' },
  { id: 3, name: 'Pedro' },
  { id: 4, name: 'Amanda' }
];

const changeName = users2.map((user) => {
  if (user.name[0] === 'A') {
    user.name = 'Anacleto';
  }
  return user;
});
console.log(changeName);

// 4.3 Dado el siguiente array, devuelve una lista que contenga los valores de la propiedad .name y añade al valor de .name el string ' (Visitado)' cuando el valor de la propiedad isVisited = true.
const cities = [
  { isVisited: true, name: 'Tokyo' },
  { isVisited: false, name: 'Madagascar' },
  { isVisited: true, name: 'Amsterdam' },
  { isVisited: false, name: 'Seul' }
];

const cityNames = cities.map((city) => {
  if (city.isVisited === true) {
    city.name += ' Visitado';
  }
  return city;
});

console.log(cityNames);

// RESULTADO
// [ 'Abel', 'Julia', 'Pedro', 'Amanda' ]
// [
//   { id: 1, name: 'Anacleto' },
//   { id: 2, name: 'Julia' },
//   { id: 3, name: 'Pedro' },
//   { id: 4, name: 'Anacleto' }
// ]
// [
//   { isVisited: true, name: 'Tokyo Visitado' },
//   { isVisited: false, name: 'Madagascar' },
//   { isVisited: true, name: 'Amsterdam Visitado' },
//   { isVisited: false, name: 'Seul' }
