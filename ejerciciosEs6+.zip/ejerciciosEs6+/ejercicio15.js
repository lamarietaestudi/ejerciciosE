// Crea una función llamada swap que reciba un array y dos parametros que sean
// indices del array. La función deberá intercambiar la posición de los valores de
// los indices que hayamos enviado como parametro. Retorna el array resultante.
// Sugerencia de array:
const fantasticFour = [
  'La antorcha humana',
  'Mr. Fantástico',
  'La mujer invisible',
  'La cosa'
];
function swap(array, indexOfArray1, indexOfArray2) {
  return array.reverse(indexOfArray1, indexOfArray2);
}
console.log(swap(fantasticFour, 'La cosa', 'La antorcha humana'));

// RESULTADO
// [
//   'La cosa',
//   'La mujer invisible',
//   'Mr. Fantástico',
//   'La antorcha humana'
// ]
