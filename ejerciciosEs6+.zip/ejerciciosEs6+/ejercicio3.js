// 3.1 Dado el siguiente array, crea una copia usando spread operators.
const pointsList0 = [32, 54, 21, 64, 75, 43];
const newPointsList0 = [...pointsList0];
console.log('Este es la copia del array pointsList0: ' + newPointsList0);

// 3.2 Dado el siguiente objeto, crea una copia usando spread operators.
const toy2 = { name: 'Bus laiyiar', date: '20-30-1995', color: 'multicolor' };
const newtoy2 = { ...toy2 };
console.log('Esta es la copia del array toy2: ', newtoy2);

// 3.3 Dado los siguientes arrays, crea un nuevo array juntandolos usando
// spread operatos.
const pointsList = [32, 54, 21, 64, 75, 43];
const pointsLis2 = [54, 87, 99, 65, 32];
const combinedpointList = [...pointsList, ...pointsLis2];
console.log('Esta es la combinación de arrays: ' + combinedpointList);

// 3.4 Dado los siguientes objetos. Crea un nuevo objeto fusionando los dos
// con spread operators.
const toy = { name: 'Bus laiyiar', date: '20-30-1995', color: 'multicolor' };
const toyUpdate = { lights: 'rgb', power: ['Volar like a dragon', 'MoonWalk'] };
const allToys = { ...toy, ...toyUpdate };
console.log(allToys);

// 3.5 Dado el siguiente array. Crear una copia de él eliminando la posición 2
// pero sin editar el array inicial. De nuevo, usando spread operator.
const colors = ['rojo', 'azul', 'amarillo', 'verde', 'naranja'];
const [color0, color1, , ...restoColores] = colors;
console.log(color0, color1, restoColores);

// RESULTADO

// Este es la copia del array pointsList0: 32,54,21,64,75,43
// Esta es la copia del array toy2:  { name: 'Bus laiyiar', date: '20-30-1995', color: 'multicolor' }
// Esta es la combinación de arrays: 32,54,21,64,75,43,54,87,99,65,32
// {
//   name: 'Bus laiyiar',
//   date: '20-30-1995',
//   color: 'multicolor',
//   lights: 'rgb',
//   power: [ 'Volar like a dragon', 'MoonWalk' ]
// }
// rojo azul [ 'verde', 'naranja' ] >> NO SÉ CÓMO HACER QUE QUEDEN TODOS DENTRO DE UN ARRAY.
